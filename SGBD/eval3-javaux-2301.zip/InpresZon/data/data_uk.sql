-- INSERT INTO site_fournisseur VALUES (1, 'Amazon');
INSERT INTO site_fournisseur VALUES (2, 'LDLC');
INSERT INTO site_fournisseur VALUES (3, 'Rue du Commerce');
INSERT INTO site_fournisseur VALUES (4, 'Pixmania');
INSERT INTO site_fournisseur VALUES (5, 'Ebay');
INSERT INTO site_fournisseur VALUES (6, 'Fnac');
INSERT INTO site_fournisseur VALUES (7, 'Alternate');
INSERT INTO site_fournisseur VALUES (8, 'Kelkoo');
INSERT INTO site_fournisseur VALUES (9, 'Cdiscount');
INSERT INTO site_fournisseur VALUES (10, 'Oka');

commit;