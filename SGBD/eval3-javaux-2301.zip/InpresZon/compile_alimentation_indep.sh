fsharpc -O --debug --resident -r System.Xml.Linq.dll alimentation_indep.fs
